# Loxberry Plugin: MQTT/RF433 Gateway

Loxberry plugin to control RF433 devices via MQTT messages.

## Installation

Install this plugin like any other. The MQTT Gateway plugin must be installed as well

## Configuration


